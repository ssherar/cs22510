int load_log_file(char filename[]);
int close_log_file();
void append_log_file(char action[]);
int get_lock(char filename[]);
